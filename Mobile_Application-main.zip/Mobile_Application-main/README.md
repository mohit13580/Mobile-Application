# Mobile_Application

There are two folders uploaded in this GitHub Repository. 

One is a Flutter folder which contains the front end of the application

The other is the Node.js component which constitutes the back-end for the application
