import 'package:flutter/material.dart';

mixin Strings {
  static bool registered = false;

  static String token = "null";
}
