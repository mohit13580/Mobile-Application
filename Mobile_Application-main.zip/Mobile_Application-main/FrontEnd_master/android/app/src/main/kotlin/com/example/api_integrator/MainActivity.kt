package com.example.api_integrator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
